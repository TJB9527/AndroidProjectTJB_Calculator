package cn.edu.bistu.calculatortjb;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Stack;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static String TheJudgeList[][] =
            {
                    //+    -    *    /    (    )    ^     %      --------栈顶运算符
                    {">", ">", "<", "<", "<", ">", "<", "<"},// +

                    {">", ">", "<", "<", "<", ">", "<", "<"},// -

                    {">", ">", ">", ">", "<", ">", "<", "<"},// *

                    {">", ">", ">", ">", "<", ">", "<", "<"},// /

                    {"<", "<", "<", "<", "<", "=", "<", "<"},// (

                    {">", ">", ">", ">", "0", ">", ">", ">"},// )

                    {">", ">", ">", ">", "<", ">", "<", "<"},// ^

                    {">", ">", ">", ">", "<", ">", "<", "<"},// %

            };
    HashMap<Integer,String> HashFunc = new HashMap<>();
    private Integer key=0;//保存sin\cos\lg\ln在哈希表中的对应键值
    private int BracketNum=0;//自出现三角、对数函数开始统计左括号数量
    private boolean TheMinHelper = false; //入栈的数是负数的标志，入栈时需乘-1再入栈
    private int changetoF=0;//=1表示切换成负数，=0表示切换成正数    在+-*/后执行changetoF=0可实现后面的数的正负数切换
    private int changeNumCount=0;//正负数切换时记录要正负变换的对象的位数
    private int AllBracketLeft=0;
    private int AllBracketRight=0;
    private boolean flagCharactor=false;//flagPoint与flagCharactor亮哥变量联合避免多个小数点连续输入的错误
    private boolean flagPoint=false;
    Stack<String> Character = new Stack<String>();
    Stack<BigDecimal> figure = new Stack<>();
    private boolean zero_trigger = false;
    private boolean NewTrigger = false;
    private boolean NumLogic_trigger = false;
    private boolean C_trigger = false;
    private int i = 0;
    private String logic_Symbol;
    private Button one;
    private Button two;
    private Button three;
    private Button four;
    private Button five;
    private Button six;
    private Button seven;
    private Button eight;
    private Button nine;
    private Button zero;
    private Button del;
    private Button plus;
    private Button times;
    private Button minus;
    private Button cancel;
    private Button div;
    private Button equal;
    private Button point;
    private Button Remainder;
    private Button LeftBracket;
    private Button RightBracket;
    private Button Double;
    private Button sin;
    private TextView editLine;
    private Button log;
    private Button lg;
    private Button change;
    private Button cos;
    private Button tan;
    @SuppressLint({"SetTextI18n", "NonConstantResourceId"})
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.one:
                changeNumCount++;
                editLine.setText(editLine.getText() + "1");
                break;
            case R.id.two:
                changeNumCount++;
                editLine.setText(editLine.getText() + "2");
                break;
            case R.id.three:
                changeNumCount++;
                editLine.setText(editLine.getText() + "3");
                break;
            case R.id.four:
                changeNumCount++;
                editLine.setText(editLine.getText() + "4");
                break;
            case R.id.five:
                changeNumCount++;
                editLine.setText(editLine.getText() + "5");
                break;
            case R.id.six:
                changeNumCount++;
                editLine.setText(editLine.getText() + "6");
                break;
            case R.id.seven:
                changeNumCount++;
                editLine.setText(editLine.getText() + "7");
                break;
            case R.id.eight:
                changeNumCount++;
                editLine.setText(editLine.getText() + "8");
                break;
            case R.id.nine:
                changeNumCount++;
                editLine.setText(editLine.getText() + "9");
                break;
            case R.id.zero:
                changeNumCount++;
                String str = editLine.getText().toString();
                if(!str.equals("")){
                    if((str.charAt(str.length()-1))=='/'){
                        Toast.makeText(this,"Input Error(Point repeat)",Toast.LENGTH_SHORT).show();
                    }else
                        editLine.setText(editLine.getText() + "0");
                }
                else
                    editLine.setText(editLine.getText() + "0");
                break;
            case R.id.point:  //小数点合法情况：前面一位字符只能是数字且当前运算数不存在小数点
                String sP = editLine.getText().toString();
                int k = 0;
                int j = sP.length()-1;
                while(j>0){
                    if(sP.charAt(j)=='.'){
                        flagPoint=true;
                        k = j; //k记录遍历到第一个小数点的位置
                        System.out.println("第一个小数点位置："+j);
                        for(int m = sP.length()-1; m > k; m-- ){ //反向遍历到第一个小数点前碰到运算符，说明当前加的.可加
                            char cP = sP.charAt(m);
                            System.out.println("当前遍历的字符是："+cP+"-----索引值是："+m);
                            if(cP=='+'||cP=='-'||cP=='*'||cP=='/'||cP=='%'){
                                flagCharactor=true;
                                break;
                            }
                        }
                        break;//遍历到第一个小数点后退出
                    }
                    else
                        j--;
                }
                System.out.println("当前表达式："+sP);
                System.out.println("flagPoint:"+flagPoint+"----"+"flagCharactor:"+flagCharactor);

                if(getLastA()>=48&&getLastA()<=57){
                    if(flagPoint==false||flagCharactor==true){  //前面没有遍历到小数点或者小数点前有运算符
                        changeNumCount++;
                        editLine.setText(editLine.getText() + ".");
                        flagCharactor=false;
                        flagPoint=false;
                    }
                    else{
                        flagCharactor=false;
                        flagPoint=false;
                        Toast.makeText(this,"Input Error",Toast.LENGTH_SHORT).show();
                    }

                }
                else{
                    flagCharactor=false;
                    flagPoint=false;
                    Toast.makeText(this,"Input Error",Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.cancel:
                editLine.setText("");
                FigureDestroy();
                break;
            case R.id.del:
                changeNumCount--;
                String a = editLine.getText().toString();
                if (a.equals("") || a.equals("0")) {
                    Toast.makeText(this, "input Error!", Toast.LENGTH_SHORT).show();
                    break;
                }
                editLine.setText(editLine.getText().toString().substring(0, editLine.getText().toString().length() - 1));
                break;
            case R.id.div:
                changeNumCount=0;
                changetoF=0;  //使可以实现第二个数的正负切换
                if(!editLine.getText().toString().equals("")&&(getLastA()>=48&&getLastA()<=57||getLastA()==41)){//输入运算符的条件是：editLine不空且前一位是数字或右括号
                    editLine.setText(editLine.getText() + "/");
                }
                else
                    Toast.makeText(this,"input Error!",Toast.LENGTH_SHORT).show();
                break;
            case R.id.times://乘法
                changeNumCount=0;
                changetoF=0;
                if(!editLine.getText().toString().equals("")&&(getLastA()>=48&&getLastA()<=57||getLastA()==41)){
                    editLine.setText(editLine.getText() + "*");

                }
                else Toast.makeText(this,"input Error!",Toast.LENGTH_SHORT).show();
                break;
            case R.id.plus:
                changeNumCount=0;
                changetoF=0;
                if(!editLine.getText().toString().equals("")&&(getLastA()>=48&&getLastA()<=57||getLastA()==41)){
                    editLine.setText(editLine.getText() + "+");

                }
                else
                    Toast.makeText(this,"input Error!",Toast.LENGTH_SHORT).show();
                break;
            case R.id.minus:
                changeNumCount=0;
                changetoF=0;
                if(!editLine.getText().toString().equals("")&&(getLastA()>=48&&getLastA()<=57||getLastA()==41)){
                    editLine.setText(editLine.getText() + "-");

                }
                else Toast.makeText(this,"input Error!",Toast.LENGTH_SHORT).show();
                break;
            case R.id.Remainder://模运算（取余）
                changeNumCount=0;
                changetoF=0;
                if(!editLine.getText().toString().equals("")&&(getLastA()>=48&&getLastA()<=57||getLastA()==41)){
                    editLine.setText(editLine.getText() + "%");

                }
                else Toast.makeText(this,"input Error!",Toast.LENGTH_SHORT).show();
                break;

            case R.id.equal:

                String sEq = editLine.getText().toString();
                sEq = sEq.substring(sEq.length()-1);
                if(AllBracketLeft!=AllBracketRight){
                    Toast.makeText(this, "input error!", Toast.LENGTH_SHORT).show();
                    break;
                }
                if(editLine.getText().toString().equals("")||sEq.equals(".")) {
                    Toast.makeText(this, "input error!", Toast.LENGTH_SHORT).show();
                } else {
                    System.out.println("--------------当前执行=操作----------------");
                    equal_cul();
                    String ReInitText = figure.pop().toString();

                    //运算结果为负数（如-2，此负数不带括号），如果直接按+/-键切换有两种形式（1.-2——>2  2.-2-->-(-2)）
                    if(ReInitText.substring(0,1).equals("-"))
                        changeNumCount=ReInitText.length()-1;
                    else
                        changeNumCount=ReInitText.length();

                    editLine.setText(ReInitText);
                    NewTrigger = true;
                    changetoF=0;
                    System.out.println("--------------=操作执行完成----------------");
                }
                break;

            case R.id.RightBrackets://前面不能是空或小数点
                if(AllBracketLeft>AllBracketRight){
                    if(!editLine.getText().toString().equals("")&&getTextLast()!='.') {
                        editLine.setText(editLine.getText() + ")");
                        AllBracketRight++;
                    }
                }
                else
                    Toast.makeText(this, "input error!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.LeftBrackets:
                String sL = editLine.getText().toString();
                char c = sL.charAt(sL.length()-1);
                int sL1 = c;
                System.out.println("当前运算符ASCLL码值是："+c+"---"+sL1+"----------++++++++++");
                if(c!='.'&&(sL1<48||sL1>57)) {//前面不能有数字且不能有小数点
                    editLine.setText(editLine.getText() + "(");
                    AllBracketLeft++;
                }
                else
                    Toast.makeText(this, "input error!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.Double://幂运算
                changeNumCount=0;
                if(!editLine.getText().toString().equals("")&&getTextLast()!='.')
                    editLine.setText(editLine.getText() + "^");
                else
                    Toast.makeText(this,"input Error!",Toast.LENGTH_SHORT).show();
                break;
            case R.id.sin:
                changeNumCount=0;
                AllBracketLeft++;
                editLine.setText(editLine.getText() + "sin(");
                break;
            case R.id.cos:
                changeNumCount=0;
                AllBracketLeft++;
                editLine.setText(editLine.getText() + "cos(");
                break;
            case R.id.tan:
                changeNumCount=0;
                AllBracketLeft++;
                editLine.setText(editLine.getText() + "tan(");
                break;
            case R.id.log:
                changeNumCount=0;
                AllBracketLeft++;
                editLine.setText(editLine.getText() + "ln(");
                break;
            case R.id.lg:
                changeNumCount=0;
                AllBracketLeft++;
                editLine.setText(editLine.getText() + "lg(");
                break;
            case R.id.change: //正负号切换键
                String s = editLine.getText().toString();
                if(s.equals("")){
                    Toast.makeText(this, "input error!", Toast.LENGTH_SHORT).show();
                    break;
                }
                if(s.substring(0,1).equals("-")){   //如果此前运算结果为负数，且紧接着对运算结果通过按+/-键取正数，则直接将前面的负号去掉
                    s = s.substring(1,s.length());
                    editLine.setText(s);
                    break;
                }
                if(changetoF==0) {  //切换成负数   8+9 -> 8+(-9)
                    changetoF = 1;
                    System.out.println("+/-键切换");
                    System.out.println("切换成负数前表达式为："+s);
                    System.out.println("changeNumCount值为："+changeNumCount);
                    String TheFront = s.substring(0,s.length()-changeNumCount);//截取前几位
                    System.out.println("TheFront:"+TheFront);
                    String TheBACK  =s.substring(s.length()-changeNumCount,s.length());//截取后几位
                    System.out.println("TheBack："+TheBACK);
                    TheBACK="(-"+TheBACK+")";
                    s= TheFront + TheBACK;
                    System.out.println("切换成负数后表达式为："+s);
                }
                else if(changetoF == 1){  //切换回正数
                    System.out.println("+/-键切换");
                    changetoF=0;
                    String TheFront = s.substring(0,s.length()-(changeNumCount+3));//8+(-91) - > 8+9
                    System.out.println("TheFront:"+TheFront);
                    String TheBACK  =s.substring(s.length()-(changeNumCount+1),s.length()-1);
                    System.out.println("TheBack:"+TheBACK);
                    s= TheFront+TheBACK;
                    System.out.println("切换回正数后表达式为："+s);
                }
                editLine.setText(s);
                break;
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Allinit();
    }

    private void Allinit() {
        //创建所有布局控件对象实例
        lg =findViewById(R.id.lg);
        change=findViewById(R.id.change);
        log=findViewById(R.id.log);
        tan=findViewById(R.id.tan);
        cos=findViewById(R.id.cos);
        sin=findViewById(R.id.sin);
        one = findViewById(R.id.one);
        two = findViewById(R.id.two);
        three = findViewById(R.id.three);
        four = findViewById(R.id.four);
        five = findViewById(R.id.five);
        six = findViewById(R.id.six);
        seven = findViewById(R.id.seven);
        eight = findViewById(R.id.eight);
        nine = findViewById(R.id.nine);
        zero = findViewById(R.id.zero);
        point = findViewById(R.id.point);
        cancel = findViewById(R.id.cancel);
        plus = findViewById(R.id.plus);
        minus = findViewById(R.id.minus);
        times = findViewById(R.id.times);
        div = findViewById(R.id.div);
        equal = findViewById(R.id.equal);
        Double = findViewById(R.id.Double);
        del = findViewById(R.id.del);
        editLine = findViewById(R.id.editLine);
        LeftBracket = findViewById(R.id.LeftBrackets);
        RightBracket = findViewById(R.id.RightBrackets);
        Remainder = findViewById(R.id.Remainder);

        //监听事件方法
        Double.setOnClickListener(this);
        LeftBracket.setOnClickListener(this);
        RightBracket.setOnClickListener(this);
        Remainder.setOnClickListener(this);
        one.setOnClickListener(this);
        two.setOnClickListener(this);
        three.setOnClickListener(this);
        four.setOnClickListener(this);
        five.setOnClickListener(this);
        six.setOnClickListener(this);
        seven.setOnClickListener(this);
        eight.setOnClickListener(this);
        nine.setOnClickListener(this);
        div.setOnClickListener(this);
        point.setOnClickListener(this);
        zero.setOnClickListener(this);
        point.setOnClickListener(this);
        del.setOnClickListener(this);
        cancel.setOnClickListener(this);
        equal.setOnClickListener(this);
        minus.setOnClickListener(this);
        plus.setOnClickListener(this);
        times.setOnClickListener(this);
        RightBracket.setOnClickListener(this);
        LeftBracket.setOnClickListener(this);
        sin.setOnClickListener(this);
        log.setOnClickListener(this);
        lg.setOnClickListener(this);
        change.setOnClickListener(this);//正负号切换键
        tan.setOnClickListener(this);
        cos.setOnClickListener(this);
    }

    //复合表达式计算过程（栈）
    private void equal_cul() {
        String TheExpression = editLine.getText().toString();
        System.out.println(TheExpression);
        i=0;

        //开始遍历复合表达式，进行操作数和操作符的入栈操作
        System.out.println("-------开始遍历复合表达式，进行操作数和操作符的入栈操作-------");
        while (i < TheExpression.length()) {
            System.out.println("要入栈的是" + TheExpression.substring(i, i + 1));
            System.out.println("栈内有f:" + figure);
            System.out.println("c栈内有:" + Character);
            int ASC2 = TheExpression.charAt(i);//charAt()方法通过索引值i找到字符串TheExpression中对应元素并将其转换成对应ASCII码
            if (zero_trigger == true) {   //当前面一个遍历到的元素是小数点（小数点不入栈），将后一位数字连同栈顶元素（即小数点前一位数字）结合作为整体入栈
                zero_trigger = false;
                BigDecimal Thex = figure.pop();
                String TheChangeX = Thex.toString() + "." + TheExpression.substring(i, i + 1);
                figure.push(new BigDecimal(TheChangeX));
                i++;
                continue;
            } else if (TheExpression.charAt(i) == '.') {
                zero_trigger = true;
                i++;
                continue;
            } else if (!(ASC2 > 47 && ASC2 <= 58)) {   //当前遍历的元素是运算符
                String helper =TheExpression.substring(i,i+1);  //helper表运算符
                if(helper.equals("l")||helper.equals("t")||helper.equals("c")||helper.equals("s")){
                    System.out.println("拦截成功！");
                    String saveString = new String();
                    while(!TheExpression.substring(i,i+1).equals("(")){  //通过i++过滤sin/cos/log/ln后的字符
                        saveString=saveString+TheExpression.substring(i,i+1);
                        System.out.println("i为:"+i);
                        i++;
                    }
                    HashFunc.put(key,saveString);
                    key++;
                    System.out.println("侦测到三角函数！现在等式内有:"+(key)+"个待计算的三角函数!");
                    System.out.println(HashFunc);
                    System.out.println("拦截后的符号变成了"+TheExpression.substring(i,i+1));//左括号--验证
                }
                if(i==0&&helper.equals("-")){   //运算结果为负数将其压栈时标记TheMinHelper值为true,则该数入栈时乘-1再入栈
                    TheMinHelper=true;  //标志当前要入栈的是一个负数，需要在后面入栈时乘-1后入栈
                    i++;
                    continue;
                }
                if(TheExpression.substring(i,i+1).equals("(")){
                    if(TheExpression.substring(i+1,i+2).equals("-")){  //判断是带负数的左括号，则将负数转换成正数
                        System.out.println("当前左括号表示一个负数，执行负数转正数操作");  //例：8+（-9）
                        Character.push("(");
                        String TheFirst = TheExpression.substring(0,i+1);//(前字符串包括（
                        String TheLast = TheExpression.substring(i+2,TheExpression.length());//9)
                        System.out.println("TheFirst="+TheFirst);
                        System.out.println("TheLast="+TheLast);//(9)
                        TheExpression=TheFirst+TheLast;// 8+(-9)->8+(9)
                        System.out.println("This is the new Sentiment:"+TheFirst+TheLast);
                        TheMinHelper=true;  //标志当前要入栈的是一个负数，需要在后面入栈时乘-1后入栈
                        i++;
                        continue;
                    }
                    if(key==0)   //没有三角对数函数时执行
                        BracketNum--;
                    System.out.println("侦测到括号！");
                    BracketNum++;  //自碰到第一个三角函数或对数函数开始统计左括号（包括普通和非普通）数量
                    System.out.println("现在你有普通括号"+BracketNum+",三角函数括号"+key);

                }
                if (NumLogic_trigger == true) {  //说明遍历到当前运算符之前已经做了一次运算（即做了操作：将原栈顶运算符取出并将当前运算符的前一个运算符压栈，现在遍历到当前运算符）
                    NumLogic_trigger = false;
                    if (Character.size() >1) {
                        String a = Character.pop();
                        if (!a.equals(Character.peek()) && (!a.equals("+") && !a.equals("-")) && (!a.equals("*") && !a.equals("/"))) {
                            System.out.println("触发了!");//情况：2*（2+3*5）+6 ————>2*(2+15)+6在“+6”的+号入栈前继续将右括号压栈进行2+15的计算———>2*(17)+6 在“+6”的+号入栈前继续将右括号压栈进行（17）左右括号的清空
                            System.out.println(a);
                            System.out.println("此时的C" + Character);
                            Character_Push(a);//再次将右括号压栈（继续计算 原括号里面多个运算/计算完后清空该对左右括号）
                        } else {
                            Character.push(a);
                        }
                    }
                }
                Character_Push(TheExpression.substring(i, i + 1));  //运算符入栈并与运算符栈中的栈顶运算符优先级进行比较
                C_trigger = true;  //每次有运算符入栈，C_trigger=true
                i++;
                continue;
            } else {    //当前遍历的元素是数字
                if (C_trigger == true) {  //表明当前数字前一位是运算符，防止进入下面默认的if，避免与前面的数字继续拼接
                    if(TheMinHelper==true){
                        System.out.println("当前要入栈的数字是一个负数，因此首先*（-1）再入栈");
                        figure.push(new BigDecimal(TheExpression.substring(i, i + 1)).multiply(new BigDecimal(-1)));
                        TheMinHelper=false;
                    }else
                        figure.push(new BigDecimal(TheExpression.substring(i, i + 1)));  //数字入栈
                    C_trigger = false;
                    i++;
                    continue;
                }
                if (figure.empty()) {  //一开始第一位数字直接入栈
                    if(TheMinHelper==true){
                        figure.push(new BigDecimal(TheExpression.substring(i, i + 1)).multiply(new BigDecimal(-1)));
                        TheMinHelper=false;
                        i++;
                        continue;
                    }
                    figure.push(new BigDecimal(TheExpression.substring(i, i + 1)));
                    i++;
                    continue;
                }

                String TheX = figure.pop().toString();
                TheX = TheX + TheExpression.substring(i, i + 1);//字符串拼接
                System.out.println("TheX是"+TheX);
                figure.push(new BigDecimal(TheX));  //数字入栈

                i++;
            }
        }

        //所有的运算符和数字都已入栈，进行栈中剩余运算符和数字的最终运算（如下是排除用户类似最后（5）的输入）
        while (!Character.empty()) {
            String a = Character.pop();//栈顶弹栈1
            if (a.equals(")")){  //如果最后一个入栈的运算符不是右括号，仅将其弹栈
                if(!Character.empty())
                    if(!Character.peek().equals("(")){ //如果当前栈顶不是左括号
                        ReverseSymbol(Character.pop());  //栈顶弹栈2
                        Character_Push(a);
                        continue;
                    }
            }
            System.out.println("最终循环栈内有f:" + figure);
            System.out.println("最终C栈内有:" + Character);
            ReverseSymbol(a);  //当前栈顶弹栈运算符作为参数做运算
        }

        return;
    }

    /**
     *
     * @param TheSymbol
     */
    //转换运算符--最终运算时对栈中特殊情况运算符的处理（运算符和数字全部入栈后栈中为-、+或/、*,其中前者为栈底，后者为栈顶）
    private void ReverseSymbol(String TheSymbol) {
        if (Character.empty()) { //弹栈后运算符栈为空，说明当前弹出栈的运算符为复合运算最后一个运算符，直接对其做运算得到最终结果
            calculate(TheSymbol);
            return;
        }
        String A = Character.peek();  //如果弹栈后栈中还有运算符，获得栈顶运算符
        if (A.equals("-") && TheSymbol.equals("+")) {  //当弹栈运算符为+,栈顶运算符为-，则依栈的后进先出原则，会导致计算出错
            calculate("-");                  //例如表达式5-2+3，存入栈中后栈的计算顺序是5-（2+3）=5-2-3即先算2+3=5，再算5-5=0
            return;                                    //因此实际计算时真实表达式应转换为5-（2-3），即应将当前做运算的运算符由+变为-
        } else if (A.equals("/") && TheSymbol.equals("*")) {  //同理对于弹栈运算符为*,栈顶运算符为/也是如此（但若相反则不影响计算结果，如弹栈为-，栈顶为+或弹栈为/，栈顶为*）
            calculate("/");
            return;

        }
        calculate(TheSymbol);
    }

    /**
     * @param TheSymbol
     * @return
     */
    private boolean Character_Push(String TheSymbol) {
        if (Character.empty()) {
            Character.push(TheSymbol);
        } else {
            logic_Symbol = TheLogicJudge(TheSymbol);  //logic_Symbol表征当前比较的两个运算符优先级大小关系（栈顶运算符优先级-logic——Symbol--当前运算符）
            if (logic_Symbol.equals("<")) {   //当前入栈的运算符优先级大，直接入栈
                Character.push(TheSymbol);
            }
            else if (logic_Symbol.equals("=")) {  //当前入栈的运算符优先级与栈顶相等（只有左右括号相等，当复合表达式含有（5）或sin(5)会执行）
                if(key!=0){
                    System.out.println("当前key值为："+key+";当前BracketNum值为："+BracketNum);
                    if(BracketNum==key){   //比较“括号”数量(针对sin\cos\lg\ln四个进行判定),对于特殊情况sin(2*(2+3))判定左括号是否为普通还是函数的括号
                        System.out.println("在最终运算外拦截成功!");
                        Cul_tri();//调用对应三角函数（对数函数）计算
                        BracketNum--;
                        key--;
                    }
                    else{
                        System.out.println("虽然在函数内,但这是正常的括号！");//情况：sin(2*(2+3))
                        BracketNum--;
                    }
                }
                else
                    System.out.println("现在算式内没有三角函数！！");
                System.out.println("左括号弹栈");
                Character.pop();   //栈顶运算符（仅左括号）出栈
            }
            else if (logic_Symbol.equals(">")) {   //当前入栈的运算符优先级小，入栈前需要把栈中优先级大的运算符先做计算
                String TheExpression = editLine.getText().toString();
                System.out.println(TheExpression);
                System.out.println("现在的f是" + figure);
                System.out.println("现在的c是" + Character);
                System.out.println("现在的符号是" + TheSymbol);

                NumLogic_trigger = true;  //要运算时（会将栈顶运算符取出拿去运算），标记为true

                System.out.println("大于时的栈顶是:" + Character.peek());
                System.out.println("当前栈顶运算符出栈，将进行该运算符的计算---------"+Character.peek());
                calculate(Character.pop());  //把栈中优先级大的运算符弹栈后做这个运算符的计算
                Character.push(TheSymbol);   //再将当前要入栈的运算符压栈
            }

        }
        return true;
    }

    //对当前运算符栈中的栈顶运算符（已弹栈）做运算
    private void calculate(String TheSymbol) {
        System.out.println("计算前的Figure:" + figure);
        System.out.println("计算前的C:" + Character);
        if (!Character.empty()) {
            String X = Character.peek();//把当前栈顶运算符拿出来
            if (X.equals("(") && TheSymbol.equals(")")) {   //左右括号相遇
                if (key!=0)
                {
                    if(BracketNum==key){
                        System.out.println("在最终运算的时候该算三角函数了！");
                        Cul_tri();
                        Character.pop();
                        BracketNum--;
                        key--;
                        return;
                    }
                    else{
                        System.out.println("在最终运算的时候虽然在函数内,但这是正常的括号！");
                        BracketNum--;
                    }
                }
                else
                    System.out.println("在最终运算的时候现在算式内没有三角函数！！");

                Character.pop();   //左括号弹栈，当前的一对左右括号从此浪迹天涯
                return;
            }
        }
        //先将当前要运算的运算符弹栈，再将操作数栈栈顶两个元素弹栈进行运算，运算完后将结果压栈
        BigDecimal num2 = figure.pop();
        System.out.println("num2=" + num2);
        if(figure.empty()&&Character.empty()){
            figure.push(num2);
            return;
        }
        BigDecimal num1 = figure.pop();
        System.out.println("num1=" + num1);
        System.out.println("当前要进行运算的运算符是：" + TheSymbol);
        switch (TheSymbol) {
            case "+":
                figure.push(num1.add(num2));//加（大乘数类自带的加法运算）
                System.out.println("计算后的Figure:" + figure);
                System.out.println("计算后的C:" + Character);
                break;
            case "-":
                figure.push(num1.subtract(num2));//减
                System.out.println("计算后的Figure:" + figure);
                System.out.println("计算后的C:" + Character);
                break;
            case "*":
//                figure.push((num1.multiply(num2).setScale(6,BigDecimal.ROUND_HALF_UP));
                BigDecimal b1 = new BigDecimal((num1.multiply(num2).setScale(6,BigDecimal.ROUND_HALF_UP).stripTrailingZeros().toPlainString()));
                figure.push(b1);//乘（保留小数点后6位）
                System.out.println("计算后的Figure:" + figure);
                System.out.println("计算后的C:" + Character);
                break;
            case "/":
                try {
                    BigDecimal b2 = new BigDecimal((num1.divide(num2)).setScale(6,BigDecimal.ROUND_HALF_UP).stripTrailingZeros().toPlainString());
                    figure.push(b2);//除
                    System.out.println("计算后的Figure:" + figure);
                    System.out.println("计算后的C:" + Character);
                } catch (Exception e) {
                    figure.push(num1.divide(num2, 6, BigDecimal.ROUND_HALF_UP));
                    System.out.println("计算后的Figure:" + figure);
                    System.out.println("计算后的C:" + Character);
                }
                break;
            case "%":
                BigDecimal b3 = new BigDecimal((num1.remainder(num2)).setScale(6,BigDecimal.ROUND_HALF_UP).stripTrailingZeros().toPlainString());
                figure.push(b3);
                System.out.println("计算后的Figure:" + figure);
                System.out.println("计算后的C:" + Character);
                break;
            case "^":
                BigDecimal b4 = new BigDecimal((Math.pow(num1.doubleValue(), num2.doubleValue())));
                figure.push((b4));

        }

    }

    //将当前运算符与运算符栈中的栈顶运算符优先级进行比较
    private String TheLogicJudge(String TheSymbol) {
        System.out.println("进行当前入栈运算符与栈顶运算符优先级的比较");
        String thePeek = Character.peek(); //仅获得栈顶元素（非出栈）
        System.out.println("当前入栈的运算符是:" + TheSymbol);
        System.out.println("当前栈顶运算符是:" + thePeek);
        int i = 0, j = 0;
        switch (thePeek) {
            case "+":
                i = 0;
                break;

            case "-":
                i = 1;
                break;

            case "*":
                i = 2;
                break;

            case "/":
                i = 3;
                break;

            case "(":
                i = 4;
                break;

            case ")":
                i = 5;
                break;
            case "^":
                i = 6;
                break;
            case "%":
                i = 7;
                break;
        }

        switch (TheSymbol) {

            case "+":
                j = 0;
                break;

            case "-":
                j = 1;
                break;

            case "*":
                j = 2;
                break;

            case "/":
                j = 3;
                break;

            case "(":
                j = 4;
                break;

            case ")":
                j = 5;
                break;
            case "^":
                j = 6;
                break;
            case "%":
                j = 7;
                break;

        }
        return TheJudgeList[i][j];
    }

    //三角函数、对数函数的底层函数调用计算
    private void Cul_tri(){
        System.out.println("哈希表中保存了"+HashFunc);
        System.out.println("key是"+key);
        String TheX= HashFunc.get(key-1);
        System.out.println("TheX是:"+TheX);
        if(TheX.equals("sin"))
            figure.push(new BigDecimal(Math.sin(figure.pop().doubleValue())).
                    setScale(6, BigDecimal.ROUND_HALF_UP));
        else if (TheX.equals("cos"))
            figure.push(new BigDecimal(Math.cos(figure.pop().doubleValue())).
                    setScale(5, BigDecimal.ROUND_HALF_UP));
        else if (TheX.equals("tan"))
            figure.push(new BigDecimal(Math.tan(figure.pop().doubleValue())).
                    setScale(5, BigDecimal.ROUND_HALF_UP));
        else if (TheX.equals("ln"))
            figure.push(new BigDecimal(Math.log(figure.pop().doubleValue())).
                    setScale(5, BigDecimal.ROUND_HALF_UP));
        else if (TheX.equals("lg"))
            figure.push(new BigDecimal(Math.log10(figure.pop().doubleValue())).
                    setScale(5, BigDecimal.ROUND_HALF_UP));
    }

    //初始化所有内容包括栈
    private void FigureDestroy() {
        i = 0;
        BracketNum=0;
        AllBracketLeft=0;
        AllBracketRight=0;
        figure.clear();
        Character.clear();
        zero_trigger = false;
        C_trigger = false;
        NumLogic_trigger = false;
        NewTrigger = false;
        TheMinHelper=false;
        changetoF=0;
        changeNumCount=0;
    }

    //函数：获得当前editLine最后一位字符
    private char getTextLast(){
        String strG = editLine.getText().toString();
        char cLast = strG.charAt(strG.length()-1);
        return cLast;
    }

    //函数：获得当前editLine最后一位字符的ASCLL码值
    private int getLastA(){
        String strG = editLine.getText().toString();
        char cLast = strG.charAt(strG.length()-1);
        return Integer.valueOf(cLast);
    }
}
